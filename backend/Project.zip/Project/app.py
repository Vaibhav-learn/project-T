from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config
from models.order_model import db, Order
from routes.order_routes import order_bp

app = Flask(__name__)
app.config.from_object(Config)

# Initialize database
db.init_app(app)

# Register blueprints
app.register_blueprint(order_bp, url_prefix="/api/orders")

# Create tables
with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)
